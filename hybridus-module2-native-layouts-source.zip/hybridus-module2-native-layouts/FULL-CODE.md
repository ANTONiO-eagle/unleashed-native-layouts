# Полный код Модуля2 — native ASCII .kl

**UTF-8/кириллица не реализованы: точный формат базы — ASCII128×uint16. Ограничения и проверки — README-RU.md.**


## applications/main/bad_usb/bad_usb_app.c

```c

#include "bad_usb_app_i.h"
#include "helpers/ducky_layout.h"
#include <furi.h>
#include <furi_hal.h>
#include <storage/storage.h>
#include <lib/toolbox/path.h>
#include <flipper_format/flipper_format.h>

#define BAD_USB_SETTINGS_PATH           BAD_USB_APP_BASE_FOLDER "/.badusb.settings"
#define BAD_USB_SETTINGS_FILE_TYPE      "Flipper BadUSB Settings File"
#define BAD_USB_SETTINGS_VERSION        1
#define BAD_USB_SETTINGS_DEFAULT_LAYOUT BAD_USB_APP_PATH_LAYOUT_FOLDER "/en-US.kl"

static bool bad_usb_app_custom_event_callback(void* context, uint32_t event) {
    furi_assert(context);
    BadUsbApp* app = context;
    return scene_manager_handle_custom_event(app->scene_manager, event);
}

static bool bad_usb_app_back_event_callback(void* context) {
    furi_assert(context);
    BadUsbApp* app = context;
    return scene_manager_handle_back_event(app->scene_manager);
}

static void bad_usb_app_tick_event_callback(void* context) {
    furi_assert(context);
    BadUsbApp* app = context;
    scene_manager_handle_tick_event(app->scene_manager);
}

static void bad_usb_load_settings(BadUsbApp* app) {
    Storage* storage = furi_record_open(RECORD_STORAGE);
    FlipperFormat* fff = flipper_format_file_alloc(storage);
    bool loaded = false;

    BadUsbHidConfig* hid_cfg = &app->user_hid_cfg;
    FuriString* temp_str = furi_string_alloc();
    uint32_t temp_uint = 0;

    if(flipper_format_file_open_existing(fff, BAD_USB_SETTINGS_PATH)) {
        do {
            if(!flipper_format_read_header(fff, temp_str, &temp_uint)) break;
            if((strcmp(furi_string_get_cstr(temp_str), BAD_USB_SETTINGS_FILE_TYPE) != 0) ||
               (temp_uint != BAD_USB_SETTINGS_VERSION))
                break;

            if(flipper_format_read_string(fff, "layout", temp_str)) {
                furi_string_set(app->keyboard_layout, temp_str);
                FileInfo layout_file_info;
                FS_Error file_check_err = storage_common_stat(
                    storage, furi_string_get_cstr(app->keyboard_layout), &layout_file_info);
                if((file_check_err != FSE_OK) || (layout_file_info.size != 256)) {
                    furi_string_set(app->keyboard_layout, BAD_USB_SETTINGS_DEFAULT_LAYOUT);
                }
            } else {
                furi_string_set(app->keyboard_layout, BAD_USB_SETTINGS_DEFAULT_LAYOUT);
                flipper_format_rewind(fff);
            }

            if(!flipper_format_read_uint32(fff, "interface", &temp_uint, 1) ||
               temp_uint >= BadUsbHidInterfaceMAX) {
                temp_uint = BadUsbHidInterfaceUsb;
                flipper_format_rewind(fff);
            }
            app->interface = temp_uint;

            if(!flipper_format_read_bool(fff, "ble_bonding", &hid_cfg->ble.bonding, 1)) {
                hid_cfg->ble.bonding = true;
                flipper_format_rewind(fff);
            }

            if(!flipper_format_read_uint32(fff, "ble_pairing", &temp_uint, 1) ||
               temp_uint >= GapPairingCount) {
                temp_uint = GapPairingPinCodeVerifyYesNo;
                flipper_format_rewind(fff);
            }
            hid_cfg->ble.pairing = temp_uint;

            if(flipper_format_read_string(fff, "ble_name", temp_str)) {
                strlcpy(
                    hid_cfg->ble.name, furi_string_get_cstr(temp_str), sizeof(hid_cfg->ble.name));
            } else {
                hid_cfg->ble.name[0] = '\0';
                flipper_format_rewind(fff);
            }

            if(!flipper_format_read_hex(
                   fff, "ble_mac", hid_cfg->ble.mac, sizeof(hid_cfg->ble.mac))) {
                memset(hid_cfg->ble.mac, 0, sizeof(hid_cfg->ble.mac));
                flipper_format_rewind(fff);
            }

            if(flipper_format_read_string(fff, "usb_manuf", temp_str)) {
                strlcpy(
                    hid_cfg->usb.manuf,
                    furi_string_get_cstr(temp_str),
                    sizeof(hid_cfg->usb.manuf));
            } else {
                hid_cfg->usb.manuf[0] = '\0';
                flipper_format_rewind(fff);
            }

            if(flipper_format_read_string(fff, "usb_product", temp_str)) {
                strlcpy(
                    hid_cfg->usb.product,
                    furi_string_get_cstr(temp_str),
                    sizeof(hid_cfg->usb.product));
            } else {
                hid_cfg->usb.product[0] = '\0';
                flipper_format_rewind(fff);
            }

            if(!flipper_format_read_uint32(fff, "usb_vid", &hid_cfg->usb.vid, 1)) {
                hid_cfg->usb.vid = 0;
                flipper_format_rewind(fff);
            }

            if(!flipper_format_read_uint32(fff, "usb_pid", &hid_cfg->usb.pid, 1)) {
                hid_cfg->usb.pid = 0;
                flipper_format_rewind(fff);
            }

            loaded = true;
        } while(0);
    }

    furi_string_free(temp_str);

    flipper_format_free(fff);
    furi_record_close(RECORD_STORAGE);

    if(!loaded) {
        furi_string_set(app->keyboard_layout, BAD_USB_SETTINGS_DEFAULT_LAYOUT);
        app->interface = BadUsbHidInterfaceUsb;
        hid_cfg->ble.name[0] = '\0';
        memset(hid_cfg->ble.mac, 0, sizeof(hid_cfg->ble.mac));
        hid_cfg->ble.bonding = true;
        hid_cfg->ble.pairing = GapPairingPinCodeVerifyYesNo;
        hid_cfg->usb.vid = 0;
        hid_cfg->usb.pid = 0;
        hid_cfg->usb.manuf[0] = '\0';
        hid_cfg->usb.product[0] = '\0';
    }
}

static void bad_usb_save_settings(BadUsbApp* app) {
    Storage* storage = furi_record_open(RECORD_STORAGE);
    FlipperFormat* fff = flipper_format_file_alloc(storage);
    BadUsbHidConfig* hid_cfg = &app->user_hid_cfg;
    uint32_t temp_uint = 0;

    if(flipper_format_file_open_always(fff, BAD_USB_SETTINGS_PATH)) {
        do {
            if(!flipper_format_write_header_cstr(
                   fff, BAD_USB_SETTINGS_FILE_TYPE, BAD_USB_SETTINGS_VERSION))
                break;
            if(!flipper_format_write_string(fff, "layout", app->keyboard_layout)) break;
            temp_uint = app->interface;
            if(!flipper_format_write_uint32(fff, "interface", &temp_uint, 1)) break;
            if(!flipper_format_write_bool(fff, "ble_bonding", &hid_cfg->ble.bonding, 1)) break;
            temp_uint = hid_cfg->ble.pairing;
            if(!flipper_format_write_uint32(fff, "ble_pairing", &temp_uint, 1)) break;
            if(!flipper_format_write_string_cstr(fff, "ble_name", hid_cfg->ble.name)) break;
            if(!flipper_format_write_hex(
                   fff, "ble_mac", (uint8_t*)&hid_cfg->ble.mac, sizeof(hid_cfg->ble.mac)))
                break;
            if(!flipper_format_write_string_cstr(fff, "usb_manuf", hid_cfg->usb.manuf)) break;
            if(!flipper_format_write_string_cstr(fff, "usb_product", hid_cfg->usb.product)) break;
            if(!flipper_format_write_uint32(fff, "usb_vid", &hid_cfg->usb.vid, 1)) break;
            if(!flipper_format_write_uint32(fff, "usb_pid", &hid_cfg->usb.pid, 1)) break;
        } while(0);
    }

    flipper_format_free(fff);
    furi_record_close(RECORD_STORAGE);
}

void bad_usb_set_interface(BadUsbApp* app, BadUsbHidInterface interface) {
    app->interface = interface;
    bad_usb_view_set_interface(app->bad_usb_view, interface);
}

BadUsbApp* bad_usb_app_alloc(char* arg) {
    BadUsbApp* app = malloc(sizeof(BadUsbApp));

    app->bad_usb_script = NULL;

    app->file_path = furi_string_alloc();
    app->keyboard_layout = furi_string_alloc();
    if(arg && strlen(arg)) {
        furi_string_set(app->file_path, arg);
    }

    bad_usb_load_settings(app);
    ducky_layout_default_load(app->keyboard_layout);

    app->gui = furi_record_open(RECORD_GUI);
    app->notifications = furi_record_open(RECORD_NOTIFICATION);
    app->dialogs = furi_record_open(RECORD_DIALOGS);

    app->view_dispatcher = view_dispatcher_alloc();
    app->scene_manager = scene_manager_alloc(&bad_usb_scene_handlers, app);

    view_dispatcher_set_event_callback_context(app->view_dispatcher, app);
    view_dispatcher_set_tick_event_callback(
        app->view_dispatcher, bad_usb_app_tick_event_callback, 250);
    view_dispatcher_set_custom_event_callback(
        app->view_dispatcher, bad_usb_app_custom_event_callback);
    view_dispatcher_set_navigation_event_callback(
        app->view_dispatcher, bad_usb_app_back_event_callback);

    // Custom Widget
    app->widget = widget_alloc();
    view_dispatcher_add_view(
        app->view_dispatcher, BadUsbAppViewWidget, widget_get_view(app->widget));

    // Popup
    app->popup = popup_alloc();
    view_dispatcher_add_view(app->view_dispatcher, BadUsbAppViewPopup, popup_get_view(app->popup));

    app->var_item_list = variable_item_list_alloc();
    view_dispatcher_add_view(
        app->view_dispatcher,
        BadUsbAppViewConfig,
        variable_item_list_get_view(app->var_item_list));

    app->bad_usb_view = bad_usb_view_alloc();
    view_dispatcher_add_view(
        app->view_dispatcher, BadUsbAppViewWork, bad_usb_view_get_view(app->bad_usb_view));

    app->text_input = text_input_alloc();
    view_dispatcher_add_view(
        app->view_dispatcher, BadUsbAppViewTextInput, text_input_get_view(app->text_input));

    app->byte_input = byte_input_alloc();
    view_dispatcher_add_view(
        app->view_dispatcher, BadUsbAppViewByteInput, byte_input_get_view(app->byte_input));

    view_dispatcher_attach_to_gui(app->view_dispatcher, app->gui, ViewDispatcherTypeFullscreen);

    if(furi_hal_usb_is_locked()) {
        app->error = BadUsbAppErrorCloseRpc;
        app->usb_if_prev = NULL;
        scene_manager_next_scene(app->scene_manager, BadUsbSceneError);
    } else {
        app->usb_if_prev = furi_hal_usb_get_config();
        furi_check(furi_hal_usb_set_config(NULL, NULL));

        if(!furi_string_empty(app->file_path)) {
            scene_manager_set_scene_state(app->scene_manager, BadUsbSceneWork, true);
            scene_manager_next_scene(app->scene_manager, BadUsbSceneWork);
        } else {
            furi_string_set(app->file_path, BAD_USB_APP_BASE_FOLDER);
            scene_manager_next_scene(app->scene_manager, BadUsbSceneFileSelect);
        }
    }

    return app;
}

void bad_usb_app_free(BadUsbApp* app) {
    furi_assert(app);

    if(app->bad_usb_script) {
        bad_usb_script_close(app->bad_usb_script);
        app->bad_usb_script = NULL;
    }

    // Views
    view_dispatcher_remove_view(app->view_dispatcher, BadUsbAppViewWork);
    bad_usb_view_free(app->bad_usb_view);

    // Custom Widget
    view_dispatcher_remove_view(app->view_dispatcher, BadUsbAppViewWidget);
    widget_free(app->widget);

    // Popup
    view_dispatcher_remove_view(app->view_dispatcher, BadUsbAppViewPopup);
    popup_free(app->popup);

    // Config menu
    view_dispatcher_remove_view(app->view_dispatcher, BadUsbAppViewConfig);
    variable_item_list_free(app->var_item_list);

    // Text Input
    view_dispatcher_remove_view(app->view_dispatcher, BadUsbAppViewTextInput);
    text_input_free(app->text_input);

    // Byte Input
    view_dispatcher_remove_view(app->view_dispatcher, BadUsbAppViewByteInput);
    byte_input_free(app->byte_input);

    // View dispatcher
    view_dispatcher_free(app->view_dispatcher);
    scene_manager_free(app->scene_manager);

    // Close records
    furi_record_close(RECORD_GUI);
    furi_record_close(RECORD_NOTIFICATION);
    furi_record_close(RECORD_DIALOGS);

    bad_usb_save_settings(app);

    furi_string_free(app->file_path);
    furi_string_free(app->keyboard_layout);

    if(app->usb_if_prev) {
        furi_check(furi_hal_usb_set_config(app->usb_if_prev, NULL));
    }

    free(app);
}

int32_t bad_usb_app(void* p) {
    BadUsbApp* bad_usb_app = bad_usb_app_alloc((char*)p);

    view_dispatcher_run(bad_usb_app->view_dispatcher);

    bad_usb_app_free(bad_usb_app);
    return 0;
}


```


## applications/main/bad_usb/helpers/ducky_layout.c

```c

#include "ducky_layout.h"
#include <furi_hal.h>
#include <storage/storage.h>
#include <flipper_format/flipper_format.h>
#include <string.h>
#include <stdio.h>

#define TAG "DuckyLayout"
#define LAYOUT_PREF_PATH INT_PATH(".hybridus-ducky-layout")
#define LAYOUT_PREF_TYPE "Hybridus Ducky Layout"
#define LAYOUT_PREF_VERSION 1

static bool ducky_layout_token_char(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
           (c >= '0' && c <= '9') || c == '-' || c == '_';
}

static bool ducky_layout_path_valid(const char* path) {
    const size_t prefix = sizeof(DUCKY_LAYOUT_ROOT "/") - 1;
    if(!path || strncmp(path, DUCKY_LAYOUT_ROOT "/", prefix) != 0) return false;
    const char* name = path + prefix;
    const size_t len = strlen(name);
    if(len < 4 || len > 35 || strcmp(name + len - 3, ".kl") != 0) return false;
    for(size_t i = 0; i < len - 3; ++i) {
        if(!ducky_layout_token_char(name[i])) return false;
    }
    return true;
}

bool ducky_layout_load(uint16_t layout[DUCKY_LAYOUT_KEYS], const char* path) {
    furi_check(layout);
    // Reset first, never leave a previous language active on failure.
    memset(layout, 0, DUCKY_LAYOUT_KEYS * sizeof(uint16_t));
    memcpy(layout, hid_asciimap, MIN(sizeof(hid_asciimap), DUCKY_LAYOUT_KEYS * sizeof(uint16_t)));
    if(!path || !path[0]) return true; // explicit built-in en-US
    bool loaded = false;
    Storage* storage = furi_record_open(RECORD_STORAGE);
    File* file = storage_file_alloc(storage);
    uint8_t bytes[DUCKY_LAYOUT_KEYS * sizeof(uint16_t)];
    if(ducky_layout_path_valid(path) &&
       storage_file_open(file, path, FSAM_READ, FSOM_OPEN_EXISTING) &&
       storage_file_size(file) == sizeof(bytes) &&
       storage_file_read(file, bytes, sizeof(bytes)) == sizeof(bytes)) {
        for(size_t i = 0; i < DUCKY_LAYOUT_KEYS; ++i) {
            layout[i] = bytes[2 * i] | ((uint16_t)bytes[2 * i + 1] << 8);
        }
        loaded = true;
    }
    storage_file_close(file);
    storage_file_free(file);
    furi_record_close(RECORD_STORAGE);
    if(!loaded) FURI_LOG_W(TAG, "Invalid/missing .kl, using built-in en-US");
    return loaded;
}

bool ducky_layout_language(uint16_t layout[DUCKY_LAYOUT_KEYS], const char* argument) {
    furi_check(layout && argument);
    char code[33];
    size_t len = 0;
    while(*argument == ' ' || *argument == '\t') ++argument;
    while(ducky_layout_token_char(*argument) && len < sizeof(code) - 1) {
        code[len++] = *argument++;
    }
    code[len] = '\0';
    while(*argument == ' ' || *argument == '\t' || *argument == '\r' || *argument == '\n') {
        ++argument;
    }
    if(!len || *argument) {
        ducky_layout_load(layout, NULL);
        FURI_LOG_W(TAG, "Invalid DUCKY_LANG argument, using built-in en-US");
        return false;
    }
    // Only aliases confirmed by files in this exact repository.
    const char* stem = code;
    if(strcmp(code, "en") == 0) stem = "en-US";
    else if(strcmp(code, "de") == 0) stem = "de-DE";
    else if(strcmp(code, "fr") == 0) stem = "fr-FR";
    char path[sizeof(DUCKY_LAYOUT_ROOT) + sizeof(code) + 4];
    snprintf(path, sizeof(path), DUCKY_LAYOUT_ROOT "/%s.kl", stem);
    return ducky_layout_load(layout, path);
}

bool ducky_layout_ascii_string(const char* text) {
    furi_check(text);
    for(; *text; ++text) {
        if((uint8_t)*text >= DUCKY_LAYOUT_KEYS) return false;
    }
    return true;
}

void ducky_layout_default_load(FuriString* path) {
    furi_check(path);
    Storage* storage = furi_record_open(RECORD_STORAGE);
    FlipperFormat* format = flipper_format_file_alloc(storage);
    FuriString* value = furi_string_alloc();
    uint32_t version = 0;
    if(flipper_format_file_open_existing(format, LAYOUT_PREF_PATH)) {
        if(flipper_format_read_header(format, value, &version) &&
           version == LAYOUT_PREF_VERSION &&
           furi_string_cmp_str(value, LAYOUT_PREF_TYPE) == 0 &&
           flipper_format_read_string(format, "path", value) &&
           ducky_layout_path_valid(furi_string_get_cstr(value))) {
            furi_string_set(path, value);
        } else {
            furi_string_set(path, DUCKY_LAYOUT_ROOT "/en-US.kl");
            FURI_LOG_W(TAG, "Invalid default layout preference, using en-US");
        }
    }
    furi_string_free(value);
    flipper_format_free(format);
    furi_record_close(RECORD_STORAGE);
}

bool ducky_layout_default_save(const FuriString* path) {
    furi_check(path);
    if(!ducky_layout_path_valid(furi_string_get_cstr(path))) return false;
    Storage* storage = furi_record_open(RECORD_STORAGE);
    FlipperFormat* format = flipper_format_file_alloc(storage);
    bool saved = flipper_format_file_open_always(format, LAYOUT_PREF_PATH) &&
                 flipper_format_write_header_cstr(format, LAYOUT_PREF_TYPE, LAYOUT_PREF_VERSION) &&
                 flipper_format_write_string_cstr(format, "path", furi_string_get_cstr(path));
    flipper_format_free(format);
    furi_record_close(RECORD_STORAGE);
    return saved;
}


```


## applications/main/bad_usb/helpers/ducky_layout.h

```c

#pragma once

#include <furi.h>
#include <stdint.h>
#include <stdbool.h>

#define DUCKY_LAYOUT_ROOT EXT_PATH("badusb/assets/layouts")
#define DUCKY_LAYOUT_KEYS 128

// Native 095E .kl: 128 little-endian uint16 HID usages/modifiers, no Unicode index.
// These loaders always leave a complete table: requested layout or built-in en-US.
bool ducky_layout_load(uint16_t layout[DUCKY_LAYOUT_KEYS], const char* path);
bool ducky_layout_language(uint16_t layout[DUCKY_LAYOUT_KEYS], const char* argument);
// This .kl format cannot encode non-ASCII Unicode; reject before typing a line.
bool ducky_layout_ascii_string(const char* text);
// New preference is in /int (mapped to SD on 095E), legacy default is preserved
// when no preference file exists. Called at app init / explicit UI selection.
void ducky_layout_default_load(FuriString* path);
bool ducky_layout_default_save(const FuriString* path);


```


## applications/main/bad_usb/helpers/ducky_script.c

```c

#include <furi.h>
#include <furi_hal.h>
#include <gui/gui.h>
#include <input/input.h>
#include <lib/toolbox/args.h>
#include <lib/toolbox/strint.h>
#include <storage/storage.h>
#include "ducky_script.h"
#include "ducky_script_i.h"
#include "ducky_layout.h"
#include <dolphin/dolphin.h>

#define TAG "BadUsb"

#define WORKER_TAG TAG "Worker"

#define BADUSB_ASCII_TO_KEY(script, x) \
    (((uint8_t)x < 128) ? (script->layout[(uint8_t)x]) : HID_KEYBOARD_NONE)

typedef enum {
    WorkerEvtStartStop = (1 << 0),
    WorkerEvtPauseResume = (1 << 1),
    WorkerEvtEnd = (1 << 2),
    WorkerEvtConnect = (1 << 3),
    WorkerEvtDisconnect = (1 << 4),
} WorkerEvtFlags;

static const char ducky_cmd_id[] = {"ID"};
static const char ducky_cmd_bt_id[] = {"BT_ID"};
static const char ducky_cmd_ble_id[] = {"BLE_ID"};

static const uint8_t numpad_keys[10] = {
    HID_KEYPAD_0,
    HID_KEYPAD_1,
    HID_KEYPAD_2,
    HID_KEYPAD_3,
    HID_KEYPAD_4,
    HID_KEYPAD_5,
    HID_KEYPAD_6,
    HID_KEYPAD_7,
    HID_KEYPAD_8,
    HID_KEYPAD_9,
};

uint32_t ducky_get_command_len(const char* line) {
    char* first_space = strchr(line, ' ');
    return first_space ? (first_space - line) : 0;
}

bool ducky_is_line_end(const char chr) {
    return (chr == ' ') || (chr == '\0') || (chr == '\r') || (chr == '\n');
}

uint16_t ducky_get_keycode(BadUsbScript* bad_usb, const char* param, bool accept_modifiers) {
    uint16_t keycode = ducky_get_keycode_by_name(param);
    if(keycode != HID_KEYBOARD_NONE) {
        return keycode;
    }

    if(accept_modifiers) {
        uint16_t keycode = ducky_get_modifier_keycode_by_name(param);
        if(keycode != HID_KEYBOARD_NONE) {
            return keycode;
        }
    }

    if(strlen(param) > 0) {
        return BADUSB_ASCII_TO_KEY(bad_usb, param[0]) & 0xFF;
    }
    return 0;
}

bool ducky_get_number(const char* param, uint32_t* val) {
    uint32_t value = 0;
    if(strint_to_uint32(param, NULL, &value, 10) == StrintParseNoError) {
        *val = value;
        return true;
    }
    return false;
}

void ducky_numlock_on(BadUsbScript* bad_usb) {
    if((bad_usb->hid->get_led_state(bad_usb->hid_inst) & HID_KB_LED_NUM) == 0) {
        bad_usb->hid->kb_press(bad_usb->hid_inst, HID_KEYBOARD_LOCK_NUM_LOCK);
        bad_usb->hid->kb_release(bad_usb->hid_inst, HID_KEYBOARD_LOCK_NUM_LOCK);
    }
}

bool ducky_numpad_press(BadUsbScript* bad_usb, const char num) {
    if((num < '0') || (num > '9')) return false;

    uint16_t key = numpad_keys[num - '0'];
    bad_usb->hid->kb_press(bad_usb->hid_inst, key);
    bad_usb->hid->kb_release(bad_usb->hid_inst, key);

    return true;
}

bool ducky_altchar(BadUsbScript* bad_usb, const char* charcode) {
    uint8_t i = 0;
    bool state = false;

    bad_usb->hid->kb_press(bad_usb->hid_inst, KEY_MOD_LEFT_ALT);

    while(!ducky_is_line_end(charcode[i])) {
        state = ducky_numpad_press(bad_usb, charcode[i]);
        if(state == false) break;
        i++;
    }

    bad_usb->hid->kb_release(bad_usb->hid_inst, KEY_MOD_LEFT_ALT);
    return state;
}

bool ducky_altstring(BadUsbScript* bad_usb, const char* param) {
    uint32_t i = 0;
    bool state = false;

    while(param[i] != '\0') {
        if((param[i] < ' ') || (param[i] > '~')) {
            i++;
            continue; // Skip non-printable chars
        }

        char temp_str[4];
        snprintf(temp_str, 4, "%u", param[i]);

        state = ducky_altchar(bad_usb, temp_str);
        if(state == false) break;
        i++;
    }
    return state;
}

int32_t ducky_error(BadUsbScript* bad_usb, const char* text, ...) {
    va_list args;
    va_start(args, text);

    vsnprintf(bad_usb->st.error, sizeof(bad_usb->st.error), text, args);

    va_end(args);
    return SCRIPT_STATE_ERROR;
}

bool ducky_string(BadUsbScript* bad_usb, const char* param) {
    uint32_t i = 0;

    while(param[i] != '\0') {
        if(param[i] != '\n') {
            uint16_t keycode = BADUSB_ASCII_TO_KEY(bad_usb, param[i]);
            if(keycode != HID_KEYBOARD_NONE) {
                bad_usb->hid->kb_press(bad_usb->hid_inst, keycode);
                bad_usb->hid->kb_release(bad_usb->hid_inst, keycode);
            }
        } else {
            bad_usb->hid->kb_press(bad_usb->hid_inst, HID_KEYBOARD_RETURN);
            bad_usb->hid->kb_release(bad_usb->hid_inst, HID_KEYBOARD_RETURN);
        }
        i++;
    }
    bad_usb->stringdelay = 0;
    return true;
}

static bool ducky_string_next(BadUsbScript* bad_usb) {
    if(bad_usb->string_print_pos >= furi_string_size(bad_usb->string_print)) {
        return true;
    }

    char print_char = furi_string_get_char(bad_usb->string_print, bad_usb->string_print_pos);

    if(print_char != '\n') {
        uint16_t keycode = BADUSB_ASCII_TO_KEY(bad_usb, print_char);
        if(keycode != HID_KEYBOARD_NONE) {
            bad_usb->hid->kb_press(bad_usb->hid_inst, keycode);
            bad_usb->hid->kb_release(bad_usb->hid_inst, keycode);
        }
    } else {
        bad_usb->hid->kb_press(bad_usb->hid_inst, HID_KEYBOARD_RETURN);
        bad_usb->hid->kb_release(bad_usb->hid_inst, HID_KEYBOARD_RETURN);
    }

    bad_usb->string_print_pos++;

    return false;
}

static int32_t ducky_parse_line(BadUsbScript* bad_usb, FuriString* line) {
    uint32_t line_len = furi_string_size(line);
    const char* line_cstr = furi_string_get_cstr(line);

    if(line_len == 0) {
        return SCRIPT_STATE_NEXT_LINE; // Skip empty lines
    }
    FURI_LOG_D(WORKER_TAG, "line:%s", line_cstr);

    // Ducky Lang Functions
    int32_t cmd_result = ducky_execute_cmd(bad_usb, line_cstr);
    if(cmd_result != SCRIPT_STATE_CMD_UNKNOWN) {
        return cmd_result;
    }

    // Mouse Keys
    uint16_t key = ducky_get_mouse_keycode_by_name(line_cstr);
    if(key != HID_MOUSE_INVALID) {
        bad_usb->hid->mouse_press(bad_usb->hid_inst, key);
        bad_usb->hid->mouse_release(bad_usb->hid_inst, key);
        return 0;
    }

    // Parse chain of modifiers linked by spaces and hyphens
    uint16_t modifiers = 0;
    while(1) {
        key = ducky_get_next_modifier_keycode_by_name(&line_cstr);
        if(key == HID_KEYBOARD_NONE) break;

        modifiers |= key;
        char next_char = *line_cstr;
        if(next_char == ' ' || next_char == '-') line_cstr++;
    }

    // Main key
    char next_char = *line_cstr;
    key = modifiers | ducky_get_keycode(bad_usb, line_cstr, false);

    if(key == 0 && next_char) ducky_error(bad_usb, "No keycode defined for %s", line_cstr);

    bad_usb->hid->kb_press(bad_usb->hid_inst, key);
    bad_usb->hid->kb_release(bad_usb->hid_inst, key);
    return 0;
}

static bool ducky_set_usb_id(BadUsbScript* bad_usb, const char* line) {
    FuriHalUsbHidConfig* usb_hid_cfg = &bad_usb->hid_cfg->usb;

    if(sscanf(line, "%lX:%lX", &usb_hid_cfg->vid, &usb_hid_cfg->pid) == 2) {
        usb_hid_cfg->manuf[0] = '\0';
        usb_hid_cfg->product[0] = '\0';

        uint8_t id_len = ducky_get_command_len(line);
        if(!ducky_is_line_end(line[id_len + 1])) {
            sscanf(
                &line[id_len + 1],
                "%31[^\r\n:]:%31[^\r\n]",
                usb_hid_cfg->manuf,
                usb_hid_cfg->product);
        }
        FURI_LOG_D(
            WORKER_TAG,
            "set id: %04lX:%04lX mfr:%s product:%s",
            usb_hid_cfg->vid,
            usb_hid_cfg->pid,
            usb_hid_cfg->manuf,
            usb_hid_cfg->product);
        return true;
    }
    return false;
}

static bool ducky_set_ble_id(BadUsbScript* bad_usb, const char* line) {
    BleProfileHidExtParams* ble_hid_cfg = &bad_usb->hid_cfg->ble;

    size_t line_len = strlen(line);
    size_t mac_len = sizeof(ble_hid_cfg->mac) * 3; // 2 hex chars + separator per byte
    if(line_len < mac_len + 1) return false; // MAC + at least 1 char for name

    for(size_t i = 0; i < sizeof(ble_hid_cfg->mac); i++) {
        const char* hex_byte = &line[i * 3];
        // This sscanf() doesn't work well with %02hhX, need to use a u32
        uint32_t temp_uint;
        if(sscanf(hex_byte, "%02lX", &temp_uint) != 1) {
            return false;
        }
        ble_hid_cfg->mac[sizeof(ble_hid_cfg->mac) - 1 - i] = temp_uint;
    }

    strlcpy(ble_hid_cfg->name, line + mac_len, sizeof(ble_hid_cfg->name));
    FURI_LOG_D(WORKER_TAG, "set ble id: %s", line);
    return true;
}

static void bad_usb_hid_state_callback(bool state, void* context) {
    furi_assert(context);
    BadUsbScript* bad_usb = context;

    if(state == true) {
        furi_thread_flags_set(furi_thread_get_id(bad_usb->thread), WorkerEvtConnect);
    } else {
        furi_thread_flags_set(furi_thread_get_id(bad_usb->thread), WorkerEvtDisconnect);
    }
}

static bool ducky_script_preload(BadUsbScript* bad_usb, File* script_file) {
    uint8_t ret = 0;
    uint32_t line_len = 0;

    furi_string_reset(bad_usb->line);

    do {
        ret = storage_file_read(script_file, bad_usb->file_buf, FILE_BUFFER_LEN);
        for(uint16_t i = 0; i < ret; i++) {
            if(bad_usb->file_buf[i] == '\n' && line_len > 0) {
                bad_usb->st.line_nb++;
                line_len = 0;
            } else {
                if(bad_usb->st.line_nb == 0) { // Save first line
                    furi_string_push_back(bad_usb->line, bad_usb->file_buf[i]);
                }
                line_len++;
            }
        }
        if(storage_file_eof(script_file)) {
            if(line_len > 0) {
                bad_usb->st.line_nb++;
                break;
            }
        }
    } while(ret > 0);

    if(bad_usb->load_id_cfg) {
        const char* line_tmp = furi_string_get_cstr(bad_usb->line);
        BadUsbHidInterface interface = *bad_usb->interface;
        // Look for ID/BLE_ID/BT_ID command on first line
        if(strncmp(line_tmp, ducky_cmd_id, strlen(ducky_cmd_id)) == 0) {
            if(ducky_set_usb_id(bad_usb, &line_tmp[strlen(ducky_cmd_id) + 1])) {
                interface = BadUsbHidInterfaceUsb;
            }
        } else if(
            strncmp(line_tmp, ducky_cmd_ble_id, strlen(ducky_cmd_ble_id)) == 0 ||
            strncmp(line_tmp, ducky_cmd_bt_id, strlen(ducky_cmd_bt_id)) == 0) {
            if(ducky_set_ble_id(bad_usb, &line_tmp[ducky_get_command_len(line_tmp) + 1])) {
                interface = BadUsbHidInterfaceBle;
            }
        }

        // Auto-switch based on ID/BLE_ID/BT_ID command, user can override manually after
        if(interface != *bad_usb->interface) {
            *bad_usb->interface = interface;
            bad_usb->hid = bad_usb_hid_get_interface(*bad_usb->interface);
        }
    }

    bad_usb->hid_inst = bad_usb->hid->init(bad_usb->hid_cfg);
    bad_usb->hid->set_state_callback(bad_usb->hid_inst, bad_usb_hid_state_callback, bad_usb);

    storage_file_seek(script_file, 0, true);
    furi_string_reset(bad_usb->line);

    return true;
}

static int32_t ducky_script_execute_next(BadUsbScript* bad_usb, File* script_file) {
    int32_t delay_val = 0;

    if(bad_usb->repeat_cnt > 0) {
        bad_usb->repeat_cnt--;
        delay_val = ducky_parse_line(bad_usb, bad_usb->line_prev);
        if(delay_val == SCRIPT_STATE_NEXT_LINE) { // Empty line
            return 0;
        } else if(delay_val == SCRIPT_STATE_STRING_START) { // Print string with delays
            return delay_val;
        } else if(delay_val == SCRIPT_STATE_WAIT_FOR_BTN) { // wait for button
            return delay_val;
        } else if(delay_val < 0) { // Script error
            bad_usb->st.error_line = bad_usb->st.line_cur - 1;
            FURI_LOG_E(WORKER_TAG, "Unknown command at line %zu", bad_usb->st.line_cur - 1U);
            return SCRIPT_STATE_ERROR;
        } else {
            return delay_val + bad_usb->defdelay;
        }
    }

    furi_string_set(bad_usb->line_prev, bad_usb->line);
    furi_string_reset(bad_usb->line);

    while(1) {
        if(bad_usb->buf_len == 0) {
            bad_usb->buf_len = storage_file_read(script_file, bad_usb->file_buf, FILE_BUFFER_LEN);
            if(storage_file_eof(script_file)) {
                if((bad_usb->buf_len < FILE_BUFFER_LEN) && (bad_usb->file_end == false)) {
                    bad_usb->file_buf[bad_usb->buf_len] = '\n';
                    bad_usb->buf_len++;
                    bad_usb->file_end = true;
                }
            }

            bad_usb->buf_start = 0;
            if(bad_usb->buf_len == 0) return SCRIPT_STATE_END;
        }
        for(uint8_t i = bad_usb->buf_start; i < (bad_usb->buf_start + bad_usb->buf_len); i++) {
            if(bad_usb->file_buf[i] == '\n' && furi_string_size(bad_usb->line) > 0) {
                bad_usb->st.line_cur++;
                bad_usb->buf_len = bad_usb->buf_len + bad_usb->buf_start - (i + 1);
                bad_usb->buf_start = i + 1;
                furi_string_trim(bad_usb->line);
                delay_val = ducky_parse_line(bad_usb, bad_usb->line);
                if(delay_val == SCRIPT_STATE_NEXT_LINE) { // Empty line
                    return 0;
                } else if(delay_val == SCRIPT_STATE_STRING_START) { // Print string with delays
                    return delay_val;
                } else if(delay_val == SCRIPT_STATE_WAIT_FOR_BTN) { // wait for button
                    return delay_val;
                } else if(delay_val < 0) {
                    bad_usb->st.error_line = bad_usb->st.line_cur;
                    FURI_LOG_E(WORKER_TAG, "Unknown command at line %zu", bad_usb->st.line_cur);
                    return SCRIPT_STATE_ERROR;
                } else {
                    return delay_val + bad_usb->defdelay;
                }
            } else {
                furi_string_push_back(bad_usb->line, bad_usb->file_buf[i]);
            }
        }
        bad_usb->buf_len = 0;
        if(bad_usb->file_end) return SCRIPT_STATE_END;
    }

    return 0;
}

static uint32_t bad_usb_flags_get(uint32_t flags_mask, uint32_t timeout) {
    uint32_t flags = furi_thread_flags_get();
    furi_check((flags & FuriFlagError) == 0);
    if(flags == 0) {
        flags = furi_thread_flags_wait(flags_mask, FuriFlagWaitAny, timeout);
        furi_check(((flags & FuriFlagError) == 0) || (flags == (unsigned)FuriFlagErrorTimeout));
    } else {
        uint32_t state = furi_thread_flags_clear(flags);
        furi_check((state & FuriFlagError) == 0);
    }
    return flags;
}

static int32_t bad_usb_worker(void* context) {
    BadUsbScript* bad_usb = context;

    BadUsbWorkerState worker_state = BadUsbStateInit;
    BadUsbWorkerState pause_state = BadUsbStateRunning;
    int32_t delay_val = 0;

    FURI_LOG_I(WORKER_TAG, "Init");
    File* script_file = storage_file_alloc(furi_record_open(RECORD_STORAGE));
    bad_usb->line = furi_string_alloc();
    bad_usb->line_prev = furi_string_alloc();
    bad_usb->string_print = furi_string_alloc();
    bad_usb->st.elapsed = 0;

    while(1) {
        uint32_t start = furi_get_tick();
        if(worker_state == BadUsbStateInit) { // State: initialization
            start = 0;
            if(storage_file_open(
                   script_file,
                   furi_string_get_cstr(bad_usb->file_path),
                   FSAM_READ,
                   FSOM_OPEN_EXISTING)) {
                if((ducky_script_preload(bad_usb, script_file)) && (bad_usb->st.line_nb > 0)) {
                    if(bad_usb->hid->is_connected(bad_usb->hid_inst)) {
                        worker_state = BadUsbStateIdle; // Ready to run
                    } else {
                        worker_state = BadUsbStateNotConnected; // Not connected
                    }
                } else {
                    worker_state = BadUsbStateScriptError; // Script preload error
                }
            } else {
                FURI_LOG_E(WORKER_TAG, "File open error");
                worker_state = BadUsbStateFileError; // File open error
            }
            bad_usb->st.state = worker_state;

        } else if(worker_state == BadUsbStateNotConnected) { // State: Not connected
            start = 0;
            uint32_t flags = bad_usb_flags_get(
                WorkerEvtEnd | WorkerEvtConnect | WorkerEvtDisconnect | WorkerEvtStartStop,
                FuriWaitForever);

            if(flags & WorkerEvtEnd) {
                break;
            } else if(flags & WorkerEvtConnect) {
                worker_state = BadUsbStateIdle; // Ready to run
            } else if(flags & WorkerEvtStartStop) {
                worker_state = BadUsbStateWillRun; // Will run when connected
            }
            bad_usb->st.state = worker_state;

        } else if(worker_state == BadUsbStateIdle) { // State: ready to start
            start = 0;
            uint32_t flags = bad_usb_flags_get(
                WorkerEvtEnd | WorkerEvtStartStop | WorkerEvtDisconnect, FuriWaitForever);

            if(flags & WorkerEvtEnd) {
                break;
            } else if(flags & WorkerEvtStartStop) { // Start executing script
                dolphin_deed(DolphinDeedBadUsbPlayScript);
                delay_val = 0;
                bad_usb->buf_len = 0;
                bad_usb->st.line_cur = 0;
                memcpy(bad_usb->layout, bad_usb->default_layout, sizeof(bad_usb->layout));
                bad_usb->defdelay = 0;
                bad_usb->stringdelay = 0;
                bad_usb->defstringdelay = 0;
                bad_usb->repeat_cnt = 0;
                bad_usb->key_hold_nb = 0;
                bad_usb->file_end = false;
                storage_file_seek(script_file, 0, true);
                worker_state = BadUsbStateRunning;
                bad_usb->st.elapsed = 0;
            } else if(flags & WorkerEvtDisconnect) {
                worker_state = BadUsbStateNotConnected; // Disconnected
            }
            bad_usb->st.state = worker_state;

        } else if(worker_state == BadUsbStateWillRun) { // State: start on connection
            start = 0;
            uint32_t flags = bad_usb_flags_get(
                WorkerEvtEnd | WorkerEvtConnect | WorkerEvtStartStop, FuriWaitForever);

            if(flags & WorkerEvtEnd) {
                break;
            } else if(flags & WorkerEvtConnect) { // Start executing script
                dolphin_deed(DolphinDeedBadUsbPlayScript);
                delay_val = 0;
                bad_usb->buf_len = 0;
                bad_usb->st.line_cur = 0;
                memcpy(bad_usb->layout, bad_usb->default_layout, sizeof(bad_usb->layout));
                bad_usb->defdelay = 0;
                bad_usb->stringdelay = 0;
                bad_usb->defstringdelay = 0;
                bad_usb->repeat_cnt = 0;
                bad_usb->file_end = false;
                storage_file_seek(script_file, 0, true);
                // extra time for PC to recognize Flipper as keyboard
                flags = furi_thread_flags_wait(
                    WorkerEvtEnd | WorkerEvtDisconnect | WorkerEvtStartStop,
                    FuriFlagWaitAny | FuriFlagNoClear,
                    1500);
                if(flags == (unsigned)FuriFlagErrorTimeout) {
                    // If nothing happened - start script execution
                    worker_state = BadUsbStateRunning;
                    bad_usb->st.elapsed = 0;
                } else if(flags & WorkerEvtStartStop) {
                    worker_state = BadUsbStateIdle;
                    furi_thread_flags_clear(WorkerEvtStartStop);
                }
            } else if(flags & WorkerEvtStartStop) { // Cancel scheduled execution
                worker_state = BadUsbStateNotConnected;
            }
            bad_usb->st.state = worker_state;

        } else if(worker_state == BadUsbStateRunning) { // State: running
            uint16_t delay_cur = (delay_val > 100) ? (100) : (delay_val);
            uint32_t flags = furi_thread_flags_wait(
                WorkerEvtEnd | WorkerEvtStartStop | WorkerEvtPauseResume | WorkerEvtDisconnect,
                FuriFlagWaitAny,
                delay_cur);

            delay_val -= delay_cur;
            if(!(flags & FuriFlagError)) {
                if(flags & WorkerEvtEnd) {
                    break;
                } else if(flags & WorkerEvtStartStop) {
                    worker_state = BadUsbStateIdle; // Stop executing script
                    bad_usb->hid->release_all(bad_usb->hid_inst);
                } else if(flags & WorkerEvtDisconnect) {
                    worker_state = BadUsbStateNotConnected; // Disconnected
                    bad_usb->hid->release_all(bad_usb->hid_inst);
                } else if(flags & WorkerEvtPauseResume) {
                    pause_state = BadUsbStateRunning;
                    worker_state = BadUsbStatePaused; // Pause
                }
                bad_usb->st.state = worker_state;
                bad_usb->st.elapsed += (furi_get_tick() - start);
                continue;
            } else if(
                (flags == (unsigned)FuriFlagErrorTimeout) ||
                (flags == (unsigned)FuriFlagErrorResource)) {
                if(delay_val > 0) {
                    bad_usb->st.delay_remain--;
                    bad_usb->st.elapsed += (furi_get_tick() - start);
                    continue;
                }
                bad_usb->st.state = BadUsbStateRunning;
                delay_val = ducky_script_execute_next(bad_usb, script_file);
                if(delay_val == SCRIPT_STATE_ERROR) { // Script error
                    delay_val = 0;
                    worker_state = BadUsbStateScriptError;
                    bad_usb->st.state = worker_state;
                    bad_usb->hid->release_all(bad_usb->hid_inst);
                } else if(delay_val == SCRIPT_STATE_END) { // End of script
                    delay_val = 0;
                    worker_state = BadUsbStateIdle;
                    bad_usb->st.state = BadUsbStateDone;
                    bad_usb->hid->release_all(bad_usb->hid_inst);
                    bad_usb->st.elapsed += (furi_get_tick() - start);
                    continue;
                } else if(delay_val == SCRIPT_STATE_STRING_START) { // Start printing string with delays
                    delay_val = bad_usb->defdelay;
                    bad_usb->string_print_pos = 0;
                    worker_state = BadUsbStateStringDelay;
                } else if(delay_val == SCRIPT_STATE_WAIT_FOR_BTN) { // set state to wait for user input
                    worker_state = BadUsbStateWaitForBtn;
                    bad_usb->st.state = BadUsbStateWaitForBtn; // Show long delays
                } else if(delay_val > 100) {
                    bad_usb->st.state = BadUsbStateDelay; // Show long delays
                    bad_usb->st.delay_remain = delay_val / 100;
                }
            } else {
                furi_check((flags & FuriFlagError) == 0);
            }
        } else if(worker_state == BadUsbStateWaitForBtn) { // State: Wait for button Press
            start = 0;
            uint32_t flags = bad_usb_flags_get(
                WorkerEvtEnd | WorkerEvtStartStop | WorkerEvtPauseResume | WorkerEvtDisconnect,
                FuriWaitForever);
            if(!(flags & FuriFlagError)) {
                if(flags & WorkerEvtEnd) {
                    break;
                } else if(flags & WorkerEvtStartStop) {
                    delay_val = 0;
                    worker_state = BadUsbStateRunning;
                } else if(flags & WorkerEvtDisconnect) {
                    worker_state = BadUsbStateNotConnected; // Disconnected
                    bad_usb->hid->release_all(bad_usb->hid_inst);
                }
                bad_usb->st.state = worker_state;
                continue;
            }
        } else if(worker_state == BadUsbStatePaused) { // State: Paused
            start = 0;
            uint32_t flags = bad_usb_flags_get(
                WorkerEvtEnd | WorkerEvtStartStop | WorkerEvtPauseResume | WorkerEvtDisconnect,
                FuriWaitForever);
            if(!(flags & FuriFlagError)) {
                if(flags & WorkerEvtEnd) {
                    break;
                } else if(flags & WorkerEvtStartStop) {
                    worker_state = BadUsbStateIdle; // Stop executing script
                    bad_usb->st.state = worker_state;
                    bad_usb->hid->release_all(bad_usb->hid_inst);
                } else if(flags & WorkerEvtDisconnect) {
                    worker_state = BadUsbStateNotConnected; // Disconnected
                    bad_usb->st.state = worker_state;
                    bad_usb->hid->release_all(bad_usb->hid_inst);
                } else if(flags & WorkerEvtPauseResume) {
                    if(pause_state == BadUsbStateRunning) {
                        if(delay_val > 0) {
                            bad_usb->st.state = BadUsbStateDelay;
                            bad_usb->st.delay_remain = delay_val / 100;
                        } else {
                            bad_usb->st.state = BadUsbStateRunning;
                            delay_val = 0;
                        }
                        worker_state = BadUsbStateRunning; // Resume
                    } else if(pause_state == BadUsbStateStringDelay) {
                        bad_usb->st.state = BadUsbStateRunning;
                        worker_state = BadUsbStateStringDelay; // Resume
                    }
                }
                continue;
            }
        } else if(worker_state == BadUsbStateStringDelay) { // State: print string with delays
            uint32_t delay = (bad_usb->stringdelay == 0) ? bad_usb->defstringdelay :
                                                           bad_usb->stringdelay;
            uint32_t flags = bad_usb_flags_get(
                WorkerEvtEnd | WorkerEvtStartStop | WorkerEvtPauseResume | WorkerEvtDisconnect,
                delay);

            if(!(flags & FuriFlagError)) {
                if(flags & WorkerEvtEnd) {
                    break;
                } else if(flags & WorkerEvtStartStop) {
                    worker_state = BadUsbStateIdle; // Stop executing script
                    bad_usb->hid->release_all(bad_usb->hid_inst);
                } else if(flags & WorkerEvtDisconnect) {
                    worker_state = BadUsbStateNotConnected; // Disconnected
                    bad_usb->hid->release_all(bad_usb->hid_inst);
                } else if(flags & WorkerEvtPauseResume) {
                    pause_state = BadUsbStateStringDelay;
                    worker_state = BadUsbStatePaused; // Pause
                }
                bad_usb->st.state = worker_state;
                bad_usb->st.elapsed += (furi_get_tick() - start);
                continue;
            } else if(
                (flags == (unsigned)FuriFlagErrorTimeout) ||
                (flags == (unsigned)FuriFlagErrorResource)) {
                bool string_end = ducky_string_next(bad_usb);
                if(string_end) {
                    bad_usb->stringdelay = 0;
                    worker_state = BadUsbStateRunning;
                }
            } else {
                furi_check((flags & FuriFlagError) == 0);
            }
        } else if(
            (worker_state == BadUsbStateFileError) ||
            (worker_state == BadUsbStateScriptError)) { // State: error
            start = 0;
            uint32_t flags =
                bad_usb_flags_get(WorkerEvtEnd, FuriWaitForever); // Waiting for exit command

            if(flags & WorkerEvtEnd) {
                break;
            }
        }
        if(start) {
            bad_usb->st.elapsed += (furi_get_tick() - start);
        }
    }

    bad_usb->hid->set_state_callback(bad_usb->hid_inst, NULL, NULL);
    bad_usb->hid->deinit(bad_usb->hid_inst);

    storage_file_close(script_file);
    storage_file_free(script_file);
    furi_string_free(bad_usb->line);
    furi_string_free(bad_usb->line_prev);
    furi_string_free(bad_usb->string_print);

    FURI_LOG_I(WORKER_TAG, "End");

    return 0;
}

BadUsbScript* bad_usb_script_open(
    FuriString* file_path,
    BadUsbHidInterface* interface,
    BadUsbHidConfig* hid_cfg,
    bool load_id_cfg,
    const FuriString* layout_path) {
    furi_assert(file_path);

    BadUsbScript* bad_usb = malloc(sizeof(BadUsbScript));
    bad_usb->file_path = furi_string_alloc();
    furi_string_set(bad_usb->file_path, file_path);
    ducky_layout_load(bad_usb->default_layout, furi_string_get_cstr(layout_path));
    memcpy(bad_usb->layout, bad_usb->default_layout, sizeof(bad_usb->layout));

    bad_usb->st.state = BadUsbStateInit;
    bad_usb->st.error[0] = '\0';
    bad_usb->interface = interface;
    bad_usb->hid_cfg = hid_cfg;
    bad_usb->load_id_cfg = load_id_cfg;
    bad_usb->hid = bad_usb_hid_get_interface(*bad_usb->interface);

    bad_usb->thread = furi_thread_alloc_ex("BadUsbWorker", 2048, bad_usb_worker, bad_usb);
    furi_thread_start(bad_usb->thread);
    return bad_usb;
} //-V773

void bad_usb_script_close(BadUsbScript* bad_usb) {
    furi_assert(bad_usb);
    furi_thread_flags_set(furi_thread_get_id(bad_usb->thread), WorkerEvtEnd);
    furi_thread_join(bad_usb->thread);
    furi_thread_free(bad_usb->thread);
    furi_string_free(bad_usb->file_path);
    free(bad_usb);
}

void bad_usb_script_start_stop(BadUsbScript* bad_usb) {
    furi_assert(bad_usb);
    furi_thread_flags_set(furi_thread_get_id(bad_usb->thread), WorkerEvtStartStop);
}

void bad_usb_script_pause_resume(BadUsbScript* bad_usb) {
    furi_assert(bad_usb);
    furi_thread_flags_set(furi_thread_get_id(bad_usb->thread), WorkerEvtPauseResume);
}

BadUsbState* bad_usb_script_get_state(BadUsbScript* bad_usb) {
    furi_assert(bad_usb);
    return &(bad_usb->st);
}


```


## applications/main/bad_usb/helpers/ducky_script.h

```c

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include <furi.h>
#include <furi_hal.h>
#include "bad_usb_hid.h"

typedef enum {
    BadUsbStateInit,
    BadUsbStateNotConnected,
    BadUsbStateIdle,
    BadUsbStateWillRun,
    BadUsbStateRunning,
    BadUsbStateDelay,
    BadUsbStateStringDelay,
    BadUsbStateWaitForBtn,
    BadUsbStatePaused,
    BadUsbStateDone,
    BadUsbStateScriptError,
    BadUsbStateFileError,
} BadUsbWorkerState;

typedef struct {
    BadUsbWorkerState state;
    size_t line_cur;
    size_t line_nb;
    uint32_t delay_remain;
    size_t error_line;
    char error[64];
    uint32_t elapsed;
} BadUsbState;

typedef struct BadUsbScript BadUsbScript;

BadUsbScript* bad_usb_script_open(
    FuriString* file_path,
    BadUsbHidInterface* interface,
    BadUsbHidConfig* hid_cfg,
    bool load_id_cfg,
    const FuriString* layout_path);

void bad_usb_script_close(BadUsbScript* bad_usb);


void bad_usb_script_start(BadUsbScript* bad_usb);

void bad_usb_script_stop(BadUsbScript* bad_usb);

void bad_usb_script_start_stop(BadUsbScript* bad_usb);

void bad_usb_script_pause_resume(BadUsbScript* bad_usb);

BadUsbState* bad_usb_script_get_state(BadUsbScript* bad_usb);

#ifdef __cplusplus
}
#endif


```


## applications/main/bad_usb/helpers/ducky_script_commands.c

```c

#include <furi_hal.h>
#include <lib/toolbox/strint.h>
#include "ducky_script.h"
#include "ducky_script_i.h"
#include "ducky_layout.h"

typedef int32_t (*DuckyCmdCallback)(BadUsbScript* bad_usb, const char* line, int32_t param);

typedef struct {
    char* name;
    DuckyCmdCallback callback;
    int32_t param;
} DuckyCmd;

static int32_t ducky_fnc_delay(BadUsbScript* bad_usb, const char* line, int32_t param) {
    UNUSED(param);

    line = &line[ducky_get_command_len(line) + 1];
    uint32_t delay_val = 0;
    bool state = ducky_get_number(line, &delay_val);
    if((state) && (delay_val > 0)) {
        return (int32_t)delay_val;
    }

    return ducky_error(bad_usb, "Invalid number %s", line);
}

static int32_t ducky_fnc_defdelay(BadUsbScript* bad_usb, const char* line, int32_t param) {
    UNUSED(param);

    line = &line[ducky_get_command_len(line) + 1];
    bool state = ducky_get_number(line, &bad_usb->defdelay);
    if(!state) {
        return ducky_error(bad_usb, "Invalid number %s", line);
    }
    return 0;
}

static int32_t ducky_fnc_strdelay(BadUsbScript* bad_usb, const char* line, int32_t param) {
    UNUSED(param);

    line = &line[ducky_get_command_len(line) + 1];
    bool state = ducky_get_number(line, &bad_usb->stringdelay);
    if(!state) {
        return ducky_error(bad_usb, "Invalid number %s", line);
    }
    return 0;
}

static int32_t ducky_fnc_defstrdelay(BadUsbScript* bad_usb, const char* line, int32_t param) {
    UNUSED(param);

    line = &line[ducky_get_command_len(line) + 1];
    bool state = ducky_get_number(line, &bad_usb->defstringdelay);
    if(!state) {
        return ducky_error(bad_usb, "Invalid number %s", line);
    }
    return 0;
}

static int32_t ducky_fnc_string(BadUsbScript* bad_usb, const char* line, int32_t param) {
    line = &line[ducky_get_command_len(line) + 1];
    if(!ducky_layout_ascii_string(line)) {
        return ducky_error(bad_usb, "Native .kl supports ASCII, not UTF-8");
    }
    furi_string_set_str(bad_usb->string_print, line);
    if(param == 1) {
        furi_string_cat(bad_usb->string_print, "\n");
    }

    if(bad_usb->stringdelay == 0 &&
       bad_usb->defstringdelay == 0) { // stringdelay not set - run command immediately
        bool state = ducky_string(bad_usb, furi_string_get_cstr(bad_usb->string_print));
        if(!state) {
            return ducky_error(bad_usb, "Invalid string %s", line);
        }
    } else { // stringdelay is set - run command in thread to keep handling external events
        return SCRIPT_STATE_STRING_START;
    }

    return 0;
}

static int32_t ducky_fnc_language(BadUsbScript* bad_usb, const char* line, int32_t param) {
    UNUSED(param);
    const char* argument = strchr(line, ' ');
    // Absent/invalid/missing language falls back to built-in en-US with a warning.
    ducky_layout_language(bad_usb->layout, argument ? argument + 1 : "");
    return 0;
}

static int32_t ducky_fnc_repeat(BadUsbScript* bad_usb, const char* line, int32_t param) {
    UNUSED(param);

    line = &line[ducky_get_command_len(line) + 1];
    bool state = ducky_get_number(line, &bad_usb->repeat_cnt);
    if((!state) || (bad_usb->repeat_cnt == 0)) {
        return ducky_error(bad_usb, "Invalid number %s", line);
    }
    return 0;
}

static int32_t ducky_fnc_sysrq(BadUsbScript* bad_usb, const char* line, int32_t param) {
    UNUSED(param);

    line = &line[ducky_get_command_len(line) + 1];
    uint16_t key = ducky_get_keycode(bad_usb, line, false);
    bad_usb->hid->kb_press(bad_usb->hid_inst, KEY_MOD_LEFT_ALT | HID_KEYBOARD_PRINT_SCREEN);
    bad_usb->hid->kb_press(bad_usb->hid_inst, key);
    bad_usb->hid->release_all(bad_usb->hid_inst);
    return 0;
}

static int32_t ducky_fnc_altchar(BadUsbScript* bad_usb, const char* line, int32_t param) {
    UNUSED(param);

    line = &line[ducky_get_command_len(line) + 1];
    ducky_numlock_on(bad_usb);
    bool state = ducky_altchar(bad_usb, line);
    if(!state) {
        return ducky_error(bad_usb, "Invalid altchar %s", line);
    }
    return 0;
}

static int32_t ducky_fnc_altstring(BadUsbScript* bad_usb, const char* line, int32_t param) {
    UNUSED(param);

    line = &line[ducky_get_command_len(line) + 1];
    ducky_numlock_on(bad_usb);
    bool state = ducky_altstring(bad_usb, line);
    if(!state) {
        return ducky_error(bad_usb, "Invalid altstring %s", line);
    }
    return 0;
}

static int32_t ducky_fnc_hold(BadUsbScript* bad_usb, const char* line, int32_t param) {
    UNUSED(param);
    line = &line[ducky_get_command_len(line) + 1];

    if(bad_usb->key_hold_nb > (HID_KB_MAX_KEYS - 1)) {
        return ducky_error(bad_usb, "Too many keys are held");
    }

    // Handle Mouse Keys here
    uint16_t key = ducky_get_mouse_keycode_by_name(line);
    if(key != HID_MOUSE_NONE) {
        bad_usb->key_hold_nb++;
        bad_usb->hid->mouse_press(bad_usb->hid_inst, key);
        return 0;
    }

    // Handle Keyboard keys here
    key = ducky_get_keycode(bad_usb, line, true);
    if(key != HID_KEYBOARD_NONE) {
        bad_usb->key_hold_nb++;
        bad_usb->hid->kb_press(bad_usb->hid_inst, key);
        return 0;
    }

    // keyboard and mouse were none
    return ducky_error(bad_usb, "Unknown keycode for %s", line);
}

static int32_t ducky_fnc_release(BadUsbScript* bad_usb, const char* line, int32_t param) {
    UNUSED(param);
    line = &line[ducky_get_command_len(line) + 1];

    if(bad_usb->key_hold_nb == 0) {
        return ducky_error(bad_usb, "No keys are held");
    }

    // Handle Mouse Keys here
    uint16_t key = ducky_get_mouse_keycode_by_name(line);
    if(key != HID_MOUSE_NONE) {
        bad_usb->key_hold_nb--;
        bad_usb->hid->mouse_release(bad_usb->hid_inst, key);
        return 0;
    }

    //Handle Keyboard Keys here
    key = ducky_get_keycode(bad_usb, line, true);
    if(key != HID_KEYBOARD_NONE) {
        bad_usb->key_hold_nb--;
        bad_usb->hid->kb_release(bad_usb->hid_inst, key);
        return 0;
    }

    // keyboard and mouse were none
    return ducky_error(bad_usb, "No keycode defined for %s", line);
}

static int32_t ducky_fnc_media(BadUsbScript* bad_usb, const char* line, int32_t param) {
    UNUSED(param);

    line = &line[ducky_get_command_len(line) + 1];
    uint16_t key = ducky_get_media_keycode_by_name(line);
    if(key == HID_CONSUMER_UNASSIGNED) {
        return ducky_error(bad_usb, "No keycode defined for %s", line);
    }
    bad_usb->hid->consumer_press(bad_usb->hid_inst, key);
    bad_usb->hid->consumer_release(bad_usb->hid_inst, key);
    return 0;
}

static int32_t ducky_fnc_globe(BadUsbScript* bad_usb, const char* line, int32_t param) {
    UNUSED(param);

    line = &line[ducky_get_command_len(line) + 1];
    uint16_t key = ducky_get_keycode(bad_usb, line, false);
    if(key == HID_KEYBOARD_NONE) {
        return ducky_error(bad_usb, "No keycode defined for %s", line);
    }

    bad_usb->hid->consumer_press(bad_usb->hid_inst, HID_CONSUMER_FN_GLOBE);
    bad_usb->hid->kb_press(bad_usb->hid_inst, key);
    bad_usb->hid->kb_release(bad_usb->hid_inst, key);
    bad_usb->hid->consumer_release(bad_usb->hid_inst, HID_CONSUMER_FN_GLOBE);
    return 0;
}

static int32_t ducky_fnc_waitforbutton(BadUsbScript* bad_usb, const char* line, int32_t param) {
    UNUSED(param);
    UNUSED(bad_usb);
    UNUSED(line);

    return SCRIPT_STATE_WAIT_FOR_BTN;
}

static int32_t ducky_fnc_mouse_scroll(BadUsbScript* bad_usb, const char* line, int32_t param) {
    UNUSED(param);

    line = &line[strcspn(line, " ") + 1];
    int32_t mouse_scroll_dist = 0;

    if(strint_to_int32(line, NULL, &mouse_scroll_dist, 10) != StrintParseNoError) {
        return ducky_error(bad_usb, "Invalid Number %s", line);
    }

    bad_usb->hid->mouse_scroll(bad_usb->hid_inst, mouse_scroll_dist);

    return 0;
}

static int32_t ducky_fnc_mouse_move(BadUsbScript* bad_usb, const char* line, int32_t param) {
    UNUSED(param);

    line = &line[strcspn(line, " ") + 1];
    int32_t mouse_move_x = 0;
    int32_t mouse_move_y = 0;

    if(strint_to_int32(line, NULL, &mouse_move_x, 10) != StrintParseNoError) {
        return ducky_error(bad_usb, "Invalid Number %s", line);
    }

    line = &line[strcspn(line, " ") + 1];

    if(strint_to_int32(line, NULL, &mouse_move_y, 10) != StrintParseNoError) {
        return ducky_error(bad_usb, "Invalid Number %s", line);
    }

    bad_usb->hid->mouse_move(bad_usb->hid_inst, mouse_move_x, mouse_move_y);

    return 0;
}

static const DuckyCmd ducky_commands[] = {
    {"REM", NULL, -1},
    {"ID", NULL, -1},
    {"BT_ID", NULL, -1},
    {"BLE_ID", NULL, -1},
    {"DELAY", ducky_fnc_delay, -1},
    {"STRING", ducky_fnc_string, 0},
    {"STRINGLN", ducky_fnc_string, 1},
    {"DUCKY_LANG", ducky_fnc_language, -1},
    {"DEFAULT_DELAY", ducky_fnc_defdelay, -1},
    {"DEFAULTDELAY", ducky_fnc_defdelay, -1},
    {"STRINGDELAY", ducky_fnc_strdelay, -1},
    {"STRING_DELAY", ducky_fnc_strdelay, -1},
    {"DEFAULT_STRING_DELAY", ducky_fnc_defstrdelay, -1},
    {"DEFAULTSTRINGDELAY", ducky_fnc_defstrdelay, -1},
    {"REPEAT", ducky_fnc_repeat, -1},
    {"SYSRQ", ducky_fnc_sysrq, -1},
    {"ALTCHAR", ducky_fnc_altchar, -1},
    {"ALTSTRING", ducky_fnc_altstring, -1},
    {"ALTCODE", ducky_fnc_altstring, -1},
    {"HOLD", ducky_fnc_hold, -1},
    {"RELEASE", ducky_fnc_release, -1},
    {"WAIT_FOR_BUTTON_PRESS", ducky_fnc_waitforbutton, -1},
    {"MEDIA", ducky_fnc_media, -1},
    {"GLOBE", ducky_fnc_globe, -1},
    {"MOUSEMOVE", ducky_fnc_mouse_move, -1},
    {"MOUSE_MOVE", ducky_fnc_mouse_move, -1},
    {"MOUSESCROLL", ducky_fnc_mouse_scroll, -1},
    {"MOUSE_SCROLL", ducky_fnc_mouse_scroll, -1},
};

#define TAG "BadUsb"

#define WORKER_TAG TAG "Worker"

int32_t ducky_execute_cmd(BadUsbScript* bad_usb, const char* line) {
    size_t cmd_word_len = strcspn(line, " ");
    for(size_t i = 0; i < COUNT_OF(ducky_commands); i++) {
        size_t cmd_compare_len = strlen(ducky_commands[i].name);

        if(cmd_compare_len != cmd_word_len) {
            continue;
        }

        if(strncmp(line, ducky_commands[i].name, cmd_compare_len) == 0) {
            if(ducky_commands[i].callback == NULL) {
                return 0;
            } else {
                return (ducky_commands[i].callback)(bad_usb, line, ducky_commands[i].param);
            }
        }
    }

    return SCRIPT_STATE_CMD_UNKNOWN;
}


```


## applications/main/bad_usb/helpers/ducky_script_i.h

```c

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include <furi.h>
#include <furi_hal.h>
#include "ducky_script.h"
#include "bad_usb_hid.h"

#define SCRIPT_STATE_ERROR        (-1)
#define SCRIPT_STATE_END          (-2)
#define SCRIPT_STATE_NEXT_LINE    (-3)
#define SCRIPT_STATE_CMD_UNKNOWN  (-4)
#define SCRIPT_STATE_STRING_START (-5)
#define SCRIPT_STATE_WAIT_FOR_BTN (-6)

#define FILE_BUFFER_LEN 16

#define HID_MOUSE_INVALID 0
#define HID_MOUSE_NONE    0

struct BadUsbScript {
    BadUsbHidInterface* interface;
    BadUsbHidConfig* hid_cfg;
    bool load_id_cfg;
    const BadUsbHidApi* hid;
    void* hid_inst;
    FuriThread* thread;
    BadUsbState st;

    FuriString* file_path;
    uint8_t file_buf[FILE_BUFFER_LEN + 1];
    uint8_t buf_start;
    uint8_t buf_len;
    bool file_end;

    uint32_t defdelay;
    uint32_t stringdelay;
    uint32_t defstringdelay;
    uint16_t layout[128];
    uint16_t default_layout[128]; // immutable after open, worker resets before each run

    FuriString* line;
    FuriString* line_prev;
    uint32_t repeat_cnt;
    uint8_t key_hold_nb;

    FuriString* string_print;
    size_t string_print_pos;
};

uint16_t ducky_get_keycode(BadUsbScript* bad_usb, const char* param, bool accept_modifiers);

uint32_t ducky_get_command_len(const char* line);

bool ducky_is_line_end(const char chr);

uint16_t ducky_get_next_modifier_keycode_by_name(const char** param);

uint16_t ducky_get_modifier_keycode_by_name(const char* param);

uint16_t ducky_get_keycode_by_name(const char* param);

uint16_t ducky_get_media_keycode_by_name(const char* param);

uint8_t ducky_get_mouse_keycode_by_name(const char* param);

bool ducky_get_number(const char* param, uint32_t* val);

void ducky_numlock_on(BadUsbScript* bad_usb);

bool ducky_numpad_press(BadUsbScript* bad_usb, const char num);

bool ducky_altchar(BadUsbScript* bad_usb, const char* charcode);

bool ducky_altstring(BadUsbScript* bad_usb, const char* param);

bool ducky_string(BadUsbScript* bad_usb, const char* param);

int32_t ducky_execute_cmd(BadUsbScript* bad_usb, const char* line);

int32_t ducky_error(BadUsbScript* bad_usb, const char* text, ...);

#ifdef __cplusplus
}
#endif


```


## applications/main/bad_usb/scenes/bad_usb_scene_config.c

```c

#include "../bad_usb_app_i.h"

enum ConfigIndex {
    ConfigIndexKeyboardLayout,
    ConfigIndexConnection,
};

enum ConfigIndexBle {
    ConfigIndexBlePersistPairing = ConfigIndexConnection + 1,
    ConfigIndexBlePairingMode,
    ConfigIndexBleSetDeviceName,
    ConfigIndexBleSetMacAddress,
    ConfigIndexBleRandomizeMacAddress,
    ConfigIndexBleRestoreDefaults,
    ConfigIndexBleRemovePairing,
};

enum ConfigIndexUsb {
    ConfigIndexUsbSetManufacturerName = ConfigIndexConnection + 1,
    ConfigIndexUsbSetProductName,
    ConfigIndexUsbSetVidPid,
    ConfigIndexUsbRandomizeVidPid,
    ConfigIndexUsbRestoreDefaults,
};

void bad_usb_scene_config_connection_callback(VariableItem* item) {
    BadUsbApp* bad_usb = variable_item_get_context(item);
    bad_usb_set_interface(
        bad_usb,
        bad_usb->interface == BadUsbHidInterfaceBle ? BadUsbHidInterfaceUsb :
                                                      BadUsbHidInterfaceBle);
    variable_item_set_current_value_text(
        item, bad_usb->interface == BadUsbHidInterfaceBle ? "BLE" : "USB");
    view_dispatcher_send_custom_event(bad_usb->view_dispatcher, ConfigIndexConnection);
}

void bad_usb_scene_config_ble_persist_pairing_callback(VariableItem* item) {
    BadUsbApp* bad_usb = variable_item_get_context(item);
    bool value = variable_item_get_current_value_index(item);
    const BadUsbHidApi* hid = bad_usb_hid_get_interface(bad_usb->interface);
    // Apply to current script config
    bad_usb->script_hid_cfg.ble.bonding = value;
    hid->adjust_config(&bad_usb->script_hid_cfg);
    // Set in user config to save in settings file
    bad_usb->user_hid_cfg.ble.bonding = value;
    variable_item_set_current_value_text(item, value ? "ON" : "OFF");
}

const char* const ble_pairing_mode_names[GapPairingCount] = {
    "YesNo",
    "PIN Type",
    "PIN Y/N",
};
void bad_usb_scene_config_ble_pairing_mode_callback(VariableItem* item) {
    BadUsbApp* bad_usb = variable_item_get_context(item);
    uint8_t index = variable_item_get_current_value_index(item);
    const BadUsbHidApi* hid = bad_usb_hid_get_interface(bad_usb->interface);
    // Apply to current script config
    bad_usb->script_hid_cfg.ble.pairing = index;
    hid->adjust_config(&bad_usb->script_hid_cfg);
    // Set in user config to save in settings file
    bad_usb->user_hid_cfg.ble.pairing = index;
    variable_item_set_current_value_text(item, ble_pairing_mode_names[index]);
}

void bad_usb_scene_config_select_callback(void* context, uint32_t index) {
    BadUsbApp* bad_usb = context;

    view_dispatcher_send_custom_event(bad_usb->view_dispatcher, index);
}

static void draw_menu(BadUsbApp* bad_usb) {
    VariableItemList* var_item_list = bad_usb->var_item_list;
    VariableItem* item;

    variable_item_list_reset(var_item_list);

    variable_item_list_add(var_item_list, "Default layout (USB/BLE)", 0, NULL, NULL);

    item = variable_item_list_add(
        var_item_list, "Connection", 2, bad_usb_scene_config_connection_callback, bad_usb);
    variable_item_set_current_value_index(item, bad_usb->interface == BadUsbHidInterfaceBle);
    variable_item_set_current_value_text(
        item, bad_usb->interface == BadUsbHidInterfaceBle ? "BLE" : "USB");

    if(bad_usb->interface == BadUsbHidInterfaceBle) {
        BleProfileHidExtParams* ble_hid_cfg = &bad_usb->script_hid_cfg.ble;

        item = variable_item_list_add(
            var_item_list,
            "Persist Pairing",
            2,
            bad_usb_scene_config_ble_persist_pairing_callback,
            bad_usb);
        variable_item_set_current_value_index(item, ble_hid_cfg->bonding);
        variable_item_set_current_value_text(item, ble_hid_cfg->bonding ? "ON" : "OFF");

        item = variable_item_list_add(
            var_item_list,
            "Pairing Mode",
            GapPairingCount,
            bad_usb_scene_config_ble_pairing_mode_callback,
            bad_usb);
        variable_item_set_current_value_index(item, ble_hid_cfg->pairing);
        variable_item_set_current_value_text(item, ble_pairing_mode_names[ble_hid_cfg->pairing]);

        variable_item_list_add(var_item_list, "Set Device Name", 0, NULL, NULL);

        variable_item_list_add(var_item_list, "Set MAC Address", 0, NULL, NULL);

        variable_item_list_add(var_item_list, "Randomize MAC Address", 0, NULL, NULL);

        variable_item_list_add(var_item_list, "Restore BLE Defaults", 0, NULL, NULL);

        variable_item_list_add(var_item_list, "Remove BLE Pairing", 0, NULL, NULL);
    } else {
        variable_item_list_add(var_item_list, "Set Manufacturer Name", 0, NULL, NULL);

        variable_item_list_add(var_item_list, "Set Product Name", 0, NULL, NULL);

        variable_item_list_add(var_item_list, "Set VID and PID", 0, NULL, NULL);

        variable_item_list_add(var_item_list, "Randomize VID and PID", 0, NULL, NULL);

        variable_item_list_add(var_item_list, "Restore USB Defaults", 0, NULL, NULL);
    }
}

void bad_usb_scene_config_on_enter(void* context) {
    BadUsbApp* bad_usb = context;
    VariableItemList* var_item_list = bad_usb->var_item_list;

    variable_item_list_set_enter_callback(
        var_item_list, bad_usb_scene_config_select_callback, bad_usb);
    draw_menu(bad_usb);
    variable_item_list_set_selected_item(
        var_item_list, scene_manager_get_scene_state(bad_usb->scene_manager, BadUsbSceneConfig));

    view_dispatcher_switch_to_view(bad_usb->view_dispatcher, BadUsbAppViewConfig);
}

bool bad_usb_scene_config_on_event(void* context, SceneManagerEvent event) {
    BadUsbApp* bad_usb = context;
    bool consumed = false;

    if(event.type == SceneManagerEventTypeCustom) {
        scene_manager_set_scene_state(bad_usb->scene_manager, BadUsbSceneConfig, event.event);
        consumed = true;
        const BadUsbHidApi* hid = bad_usb_hid_get_interface(bad_usb->interface);

        switch(event.event) {
        case ConfigIndexKeyboardLayout:
            scene_manager_next_scene(bad_usb->scene_manager, BadUsbSceneConfigLayout);
            break;
        case ConfigIndexConnection:
            // Refresh default values for new interface
            hid->adjust_config(&bad_usb->script_hid_cfg);
            // Redraw menu with new interface options
            draw_menu(bad_usb);
            break;
        default:
            break;
        }
        if(bad_usb->interface == BadUsbHidInterfaceBle) {
            switch(event.event) {
            case ConfigIndexBleSetDeviceName:
                scene_manager_next_scene(bad_usb->scene_manager, BadUsbSceneConfigBleName);
                break;
            case ConfigIndexBleSetMacAddress:
                scene_manager_next_scene(bad_usb->scene_manager, BadUsbSceneConfigBleMac);
                break;
            case ConfigIndexBleRandomizeMacAddress:
                // Apply to current script config
                furi_hal_random_fill_buf(
                    bad_usb->script_hid_cfg.ble.mac, sizeof(bad_usb->script_hid_cfg.ble.mac));
                bad_usb->script_hid_cfg.ble.mac[sizeof(bad_usb->script_hid_cfg.ble.mac) - 1] |=
                    0b11 << 6; // Set 2 MSB for Random Static Address
                hid->adjust_config(&bad_usb->script_hid_cfg);
                // Set in user config to save in settings file
                memcpy(
                    bad_usb->user_hid_cfg.ble.mac,
                    bad_usb->script_hid_cfg.ble.mac,
                    sizeof(bad_usb->user_hid_cfg.ble.mac));
                scene_manager_next_scene(bad_usb->scene_manager, BadUsbSceneDone);
                break;
            case ConfigIndexBleRestoreDefaults:
                // Apply to current script config
                bad_usb->script_hid_cfg.ble.name[0] = '\0';
                memset(
                    bad_usb->script_hid_cfg.ble.mac, 0, sizeof(bad_usb->script_hid_cfg.ble.mac));
                bad_usb->script_hid_cfg.ble.bonding = true;
                bad_usb->script_hid_cfg.ble.pairing = GapPairingPinCodeVerifyYesNo;
                hid->adjust_config(&bad_usb->script_hid_cfg);
                // Set in user config to save in settings file
                memcpy(
                    &bad_usb->user_hid_cfg.ble,
                    &bad_usb->script_hid_cfg.ble,
                    sizeof(bad_usb->user_hid_cfg.ble));
                scene_manager_next_scene(bad_usb->scene_manager, BadUsbSceneDone);
                break;
            case ConfigIndexBleRemovePairing:
                scene_manager_next_scene(bad_usb->scene_manager, BadUsbSceneConfirmUnpair);
                break;
            default:
                break;
            }
        } else {
            switch(event.event) {
            case ConfigIndexUsbSetManufacturerName:
                scene_manager_set_scene_state(
                    bad_usb->scene_manager, BadUsbSceneConfigUsbName, true);
                scene_manager_next_scene(bad_usb->scene_manager, BadUsbSceneConfigUsbName);
                break;
            case ConfigIndexUsbSetProductName:
                scene_manager_set_scene_state(
                    bad_usb->scene_manager, BadUsbSceneConfigUsbName, false);
                scene_manager_next_scene(bad_usb->scene_manager, BadUsbSceneConfigUsbName);
                break;
            case ConfigIndexUsbSetVidPid:
                scene_manager_next_scene(bad_usb->scene_manager, BadUsbSceneConfigUsbVidPid);
                break;
            case ConfigIndexUsbRandomizeVidPid:
                furi_hal_random_fill_buf(
                    (void*)bad_usb->usb_vidpid_buf, sizeof(bad_usb->usb_vidpid_buf));
                // Apply to current script config
                bad_usb->script_hid_cfg.usb.vid = bad_usb->usb_vidpid_buf[0];
                bad_usb->script_hid_cfg.usb.pid = bad_usb->usb_vidpid_buf[1];
                hid->adjust_config(&bad_usb->script_hid_cfg);
                // Set in user config to save in settings file
                bad_usb->user_hid_cfg.usb.vid = bad_usb->script_hid_cfg.usb.vid;
                bad_usb->user_hid_cfg.usb.pid = bad_usb->script_hid_cfg.usb.pid;
                scene_manager_next_scene(bad_usb->scene_manager, BadUsbSceneDone);
                break;
            case ConfigIndexUsbRestoreDefaults:
                // Apply to current script config
                bad_usb->script_hid_cfg.usb.vid = 0;
                bad_usb->script_hid_cfg.usb.pid = 0;
                bad_usb->script_hid_cfg.usb.manuf[0] = '\0';
                bad_usb->script_hid_cfg.usb.product[0] = '\0';
                hid->adjust_config(&bad_usb->script_hid_cfg);
                // Set in user config to save in settings file
                memcpy(
                    &bad_usb->user_hid_cfg.usb,
                    &bad_usb->script_hid_cfg.usb,
                    sizeof(bad_usb->user_hid_cfg.usb));
                scene_manager_next_scene(bad_usb->scene_manager, BadUsbSceneDone);
                break;
            default:
                break;
            }
        }
    }

    return consumed;
}

void bad_usb_scene_config_on_exit(void* context) {
    BadUsbApp* bad_usb = context;
    VariableItemList* var_item_list = bad_usb->var_item_list;

    variable_item_list_reset(var_item_list);
}


```


## applications/main/bad_usb/scenes/bad_usb_scene_config_layout.c

```c

#include "../bad_usb_app_i.h"
#include <storage/storage.h>
#include "../helpers/ducky_layout.h"

static bool bad_usb_layout_select(BadUsbApp* bad_usb) {
    furi_assert(bad_usb);

    FuriString* predefined_path;
    predefined_path = furi_string_alloc();
    if(!furi_string_empty(bad_usb->keyboard_layout)) {
        furi_string_set(predefined_path, bad_usb->keyboard_layout);
    } else {
        furi_string_set(predefined_path, BAD_USB_APP_PATH_LAYOUT_FOLDER);
    }

    DialogsFileBrowserOptions browser_options;
    dialog_file_browser_set_basic_options(
        &browser_options, BAD_USB_APP_LAYOUT_EXTENSION, &I_keyboard_10px);
    browser_options.base_path = BAD_USB_APP_PATH_LAYOUT_FOLDER;
    browser_options.skip_assets = false;

    // Input events and views are managed by file_browser
    bool res = dialog_file_browser_show(
        bad_usb->dialogs, bad_usb->keyboard_layout, predefined_path, &browser_options);

    furi_string_free(predefined_path);
    return res;
}

void bad_usb_scene_config_layout_on_enter(void* context) {
    BadUsbApp* bad_usb = context;

    FuriString* previous = furi_string_alloc_set(bad_usb->keyboard_layout);
    if(bad_usb_layout_select(bad_usb) &&
       furi_string_cmp(previous, bad_usb->keyboard_layout) != 0 &&
       !ducky_layout_default_save(bad_usb->keyboard_layout)) {
        furi_string_set(bad_usb->keyboard_layout, previous);
        dialog_message_show_storage_error(bad_usb->dialogs, "Default layout not saved");
    }
    furi_string_free(previous);

    scene_manager_previous_scene(bad_usb->scene_manager);
}

bool bad_usb_scene_config_layout_on_event(void* context, SceneManagerEvent event) {
    UNUSED(context);
    UNUSED(event);
    return false;
}

void bad_usb_scene_config_layout_on_exit(void* context) {
    UNUSED(context);
}


```


## applications/main/bad_usb/scenes/bad_usb_scene_work.c

```c

#include "../helpers/ducky_script.h"
#include "../bad_usb_app_i.h"
#include "../views/bad_usb_view.h"
#include <furi_hal.h>
#include "toolbox/path.h"

void bad_usb_scene_work_button_callback(InputKey key, void* context) {
    furi_assert(context);
    BadUsbApp* app = context;
    view_dispatcher_send_custom_event(app->view_dispatcher, key);
}

bool bad_usb_scene_work_on_event(void* context, SceneManagerEvent event) {
    BadUsbApp* app = context;
    bool consumed = false;

    if(event.type == SceneManagerEventTypeCustom) {
        if(event.event == InputKeyLeft) {
            if(bad_usb_view_is_idle_state(app->bad_usb_view)) {
                bad_usb_script_close(app->bad_usb_script);
                app->bad_usb_script = NULL;

                scene_manager_set_scene_state(app->scene_manager, BadUsbSceneConfig, 0);
                scene_manager_next_scene(app->scene_manager, BadUsbSceneConfig);
            }
            consumed = true;
        } else if(event.event == InputKeyOk) {
            bad_usb_script_start_stop(app->bad_usb_script);
            consumed = true;
        } else if(event.event == InputKeyRight) {
            if(bad_usb_view_is_idle_state(app->bad_usb_view)) {
                bad_usb_set_interface(
                    app,
                    app->interface == BadUsbHidInterfaceBle ? BadUsbHidInterfaceUsb :
                                                              BadUsbHidInterfaceBle);
                bad_usb_script_close(app->bad_usb_script);
                app->bad_usb_script = bad_usb_script_open(
                    app->file_path, &app->interface, &app->script_hid_cfg, false, app->keyboard_layout);
            } else {
                bad_usb_script_pause_resume(app->bad_usb_script);
            }
            consumed = true;
        }
    } else if(event.type == SceneManagerEventTypeTick) {
        bad_usb_view_set_state(app->bad_usb_view, bad_usb_script_get_state(app->bad_usb_script));
        bad_usb_view_set_interface(app->bad_usb_view, app->interface);
    }
    return consumed;
}

void bad_usb_scene_work_on_enter(void* context) {
    BadUsbApp* app = context;

    bad_usb_view_set_interface(app->bad_usb_view, app->interface);

    // Opening script the first time:
    // - copy user settings as base config
    // - load ID/BLE_ID/BT_ID config if present
    // Then disable this until next script selected so user can customize options
    bool first_script_load = scene_manager_get_scene_state(app->scene_manager, BadUsbSceneWork);
    if(first_script_load) {
        memcpy(&app->script_hid_cfg, &app->user_hid_cfg, sizeof(app->script_hid_cfg));
        scene_manager_set_scene_state(app->scene_manager, BadUsbSceneWork, false);
    }
    // Interface and config are passed as pointers as ID/BLE_ID/BT_ID config can modify them
    app->bad_usb_script = bad_usb_script_open(
        app->file_path, &app->interface, &app->script_hid_cfg, first_script_load, app->keyboard_layout);

    FuriString* file_name;
    file_name = furi_string_alloc();
    path_extract_filename(app->file_path, file_name, true);
    bad_usb_view_set_file_name(app->bad_usb_view, furi_string_get_cstr(file_name));
    furi_string_free(file_name);

    FuriString* layout;
    layout = furi_string_alloc();
    path_extract_filename(app->keyboard_layout, layout, true);
    bad_usb_view_set_layout(app->bad_usb_view, furi_string_get_cstr(layout));
    furi_string_free(layout);

    bad_usb_view_set_state(app->bad_usb_view, bad_usb_script_get_state(app->bad_usb_script));

    bad_usb_view_set_button_callback(app->bad_usb_view, bad_usb_scene_work_button_callback, app);
    view_dispatcher_switch_to_view(app->view_dispatcher, BadUsbAppViewWork);
}

void bad_usb_scene_work_on_exit(void* context) {
    UNUSED(context);
}


```
